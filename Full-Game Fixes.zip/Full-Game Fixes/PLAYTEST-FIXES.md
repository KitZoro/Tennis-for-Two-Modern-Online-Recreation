# Tennis for Two — Playtest fixes

This is a patched copy of the supplied v31.7.1 Full Game build.

## What changed

- Court drawing now uses LEFT_EDGE/RIGHT_EDGE (115 and 885), the same boundaries as scoring. The old line ran from 135 to 865 and hid 20 pixels of legal court on each end.
- Glow effects blend small local surfaces instead of allocating and blending three full-screen surfaces per effect. The visual result was checked against the original renderer.
- CPU shot prediction uses the game's 120 Hz discrete trajectory formula rather than simulating up to 900 steps for every candidate shot. It no longer searches for shots while the ball is travelling away.
- Local and story matches now retain elapsed time at low rendering rates, including 15 FPS. Physics remains fixed at 120 Hz. A 250 ms cap still limits catch-up after long pauses; sustained rates below 4 FPS are not guaranteed to keep real-time pace.
- Shot planning accounts for the actual serve/contact location, offers lower-power placements, and rejects risky high-power shots whose angle variation would hit the net or go out.
- Easy aims toward the middle for approachable rallies, medium uses safer placement away from the player, and hard uses tighter placement. Easy/medium miss chances are now sampled once per incoming shot (18%/4%), instead of effectively retrying until they succeed every tick. Hard has no intentional miss.

## Run

Open the `Tennis-for-Two-v31.7.1 Full Game` folder after extracting the ZIP.
Use `run_windows.bat` on Windows or `bash run_linux.sh` on Linux.
Existing Python/pygame/cryptography requirements still apply. This is a source build, not a standalone executable.

## Validation

Seven regression tests pass (`python3 -m unittest -v test_playtest_fixes` from the game folder):
- 1,000 trajectory comparisons against an independent fixed-step integration.
- 324 planned returns through the real game physics, covering three difficulties, four positions, three heights, three incoming speeds, and three shot-error seeds.
- Real serves for all CPU levels.
- Easy miss behavior across consecutive contact ticks.
- Simulation timing at 120, 60, 30, 15, and 10 render FPS.
- The actual challenge loop of all five story chapters at simulated 15 FPS.
- Rendered court pixels at both legal edges.

Additional checks: eight pixel-identical old/new glow comparisons; complete automated matches at all three difficulties; visual inspection of the rendered game screen. Against the same mirrored medium CPU with a fixed seed, the right-side easy/medium/hard opponents finished 0–7, 2–7, and 7–2 respectively. These are smoke tests, not a substitute for human difficulty feedback.

On this Linux machine, median game-frame drawing over 80 samples improved from about 14.6 ms to 0.7 ms. Hard shot planning improved from about 4.8 ms to 0.29 ms in the sampled scenario. These are component timings, not promised frame rates on another computer.

Windows execution, real internet multiplayer, and subjective difficulty were not manually playtested. Online simulation, network protocol, physics/scoring rules, audio, and story dialogue were not changed. The renderer improvements apply to all modes.

The original ZIP and original installed game files were not modified. Python bytecode caches are omitted from this package so they regenerate from the patched source.
