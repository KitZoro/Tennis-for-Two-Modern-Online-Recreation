# Start the patched game

Open **Tennis-for-Two-v31.7.1 Full Game**.

- Windows: run **run_windows.bat**.
- Linux: run **bash run_linux.sh** inside that folder.

See **PLAYTEST-FIXES.md** for changes and verification. The older root README describes a previous version; the runnable game is in the folder above.
